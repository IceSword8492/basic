package newlang3;

public enum ValueType {
	VOID,
	INTEGER,
	STRING,
	DOUBLE,
	BOOL,
}
