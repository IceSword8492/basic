package newlang4;

public class Function {
    public Function () {

    }
    public Value invoke (ExprListNode arg) {
        return null;
    }
}
