package newlang4;

public enum ValueType {
    VOID,
    INTEGER,
    STRING,
    DOUBLE,
    BOOL,
}
