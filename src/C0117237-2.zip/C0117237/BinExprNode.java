package newlang4;

import java.util.Map;
import java.util.HashMap;

public class BinExprNode extends Node {
    Node left = null;
    Node right = null;
    LexicalType operator = null;

    private static final Map<LexicalType, Integer> OPERATORS = new HashMap<>();

    static {
        OPERATORS.put(LexicalType.DIV, 1);
        OPERATORS.put(LexicalType.MUL, 1);
        OPERATORS.put(LexicalType.SUB, 2);
        OPERATORS.put(LexicalType.ADD, 2);
    }

    private BinExprNode (LexicalType operator) {
        this.operator = operator;
        type = NodeType.BIN_EXPR;
    }

    public static boolean isOperator (LexicalType type) {
        return OPERATORS.containsKey(type);
    }

    public static BinExprNode getHandler (LexicalType operator) throws Exception {
        if (!isOperator(operator)) {
            throw new Exception("Syntax Error");
        } else {
            return new BinExprNode(operator);
        }
    }

    public void setLeft (Node left) {
        this.left = left;
    }

    public void setRight (Node right) {
        this.right = right;
    }

    public int getOperatorPriority () {
        return OPERATORS.get(operator);
    }

    @Override
    public boolean parse () throws Exception {
        throw new Exception("Parsing Error");
    }

    @Override
    public String toString () {
        String opstr;
        switch (operator) {
        case DIV:
            opstr = "/";
            break;
        case MUL:
            opstr = "*";
            break;
        case SUB:
            opstr = "-";
            break;
        case ADD:
            opstr = "+";
            break;
        default:
            opstr = null;
        }
        return left + " " + right + " " + opstr;
    }
}
