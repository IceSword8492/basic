package newlang4;

public class PrintFunc extends Function {
    @Override
    public Value invoke (ExprListNode arg) {
        return null;
    }

    @Override
    public String toString () {
        return "PRINT";
    }
}
